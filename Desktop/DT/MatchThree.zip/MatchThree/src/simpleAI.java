
public class simpleAI {
	private Game game;
	private Board board;
	
	simpleAI(Game game){
		this.game = game;
	}
	
	public void playTwice() {
		
	}
	
	// NewObject<i, j, m, n, board, score>
	public void play() {
		board = game.getBoard();
		int score = board.getScore();
		int tempScore = score;
		Board tempBoard = new Board(board);
		int tempI = -1;
		int tempJ = -1;
		
		int tempM = -1;
		int tempN = -1;
		for(int i = Board.BOARDSIZE-1; i >= 0; i--) {
			for(int j = Board.BOARDSIZE-1; j >= 0; j--) {
				System.out.println("game score: " + game.getBoard().getScore()+ "\n");
				Board testBoard = new Board(board);
				testBoard.setFirstCandy(i, j);
				testBoard.setSelectedFirst();
				System.out.println(i + "       " + j);
				if(j != 0) {
				testBoard.move(i,j-1);
				if(testBoard.getScore() > tempBoard.getScore()) {
					tempScore = testBoard.getScore();
					tempBoard = new Board(testBoard);
					tempI = i;
					tempJ = j;
					tempM = i;
					tempN = j-1;
					
				}else if(testBoard.getScore() == tempBoard.getScore()) {
					if(testBoard.getChocolateNUM() > tempBoard.getChocolateNUM()) {
						tempScore = testBoard.getScore();
						tempBoard = new Board(testBoard);
						tempI = i;
						tempJ = j;
						tempM = i;
						tempN = j-1;
					}else if(testBoard.getFiveNUM() > tempBoard.getFiveNUM()) {
						tempScore = testBoard.getScore();
						tempBoard = new Board(testBoard);
						tempI = i;
						tempJ = j;
						tempM = i;
						tempN = j-1;
					}else if((testBoard.getFourXNUM() + testBoard.getFourYNUM()) > (tempBoard.getFourXNUM() + tempBoard.getFourYNUM()) ) {
						tempScore = testBoard.getScore();
						tempBoard = new Board(testBoard);
						tempI = i;
						tempJ = j;
						tempM = i;
						tempN = j-1;
					}
				}
				}
				
				if(i !=0) {
				testBoard = new Board(board);
				testBoard.setFirstCandy(i, j);
				testBoard.setSelectedFirst();
//				System.out.println(testBoard.getCandies()[8][8].color + "  color " + testBoard.getCandies()[7][8].color + "  " + testBoard.getCandies()[6][8].color);
				testBoard.move(i-1,j);
//				System.out.println(testBoard.getCandies()[8][8].color + "  color " + testBoard.getCandies()[7][8].color + "  " + testBoard.getCandies()[6][8].color);
				if(testBoard.getScore() > tempBoard.getScore()) {
					tempScore = testBoard.getScore();
					tempBoard = new Board(testBoard);
					tempI = i;
					tempJ = j;
					tempM = i-1;
					tempN = j;
					
				}else if(testBoard.getScore() == tempBoard.getScore()) {
					if(testBoard.getChocolateNUM() > tempBoard.getChocolateNUM()) {
						tempScore = testBoard.getScore();
						tempBoard = new Board(testBoard);
						tempI = i;
						tempJ = j;
						tempM = i-1;
						tempN = j;
					}else if(testBoard.getFiveNUM() > tempBoard.getFiveNUM()) {
						tempScore = testBoard.getScore();
						tempBoard = new Board(testBoard);
						tempI = i;
						tempJ = j;
						tempM = i-1;
						tempN = j;
					}else if((testBoard.getFourXNUM() + testBoard.getFourYNUM()) > (tempBoard.getFourXNUM() + tempBoard.getFourYNUM()) ) {
						tempScore = testBoard.getScore();
						tempBoard = new Board(testBoard);
						tempI = i;
						tempJ = j;
						tempM = i-1;
						tempN = j;
					}
				}
				}
			}
		}
		
		
		System.out.println(tempI + "   " + tempJ + "   " + tempM + "   " +tempN);
		// no valid move
		if(tempBoard.getScore() == board.getScore()) {
			board = new Board(game);
			play();
		}else {
			board.setSelectedFirst();
			board.setFirstCandy(tempM, tempN);
			board.move(tempI, tempJ);
		}
		

	}
}
