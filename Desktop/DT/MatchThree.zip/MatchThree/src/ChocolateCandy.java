import java.util.Random;

public class ChocolateCandy extends Candy {
	
	Random random = new Random(1000);

	public ChocolateCandy(int color, Board board,int row,int column) {
		super(color, board,row,column);		
	}

	@Override
	public void crush() {
		if (!wasCrushed){	
			
			wasCrushed = true;
			this.board.getCandies()[row][column] = null;
			int random = (int) Math.random()*6;
			for(int i = Board.BOARDSIZE-1; i >= 0; i--) {
				for(int j = Board.BOARDSIZE-1; j >= 0; j--) {
					if (this.board.getCandies()[i][j] != null && this.board.getCandies()[i][j].getColor() == random) {
						this.board.getCandies()[i][j].crush();
					}
				}
			}

		}
	}

}