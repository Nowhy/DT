public class Block extends Candy {

	public Block(int color, Board board,int row,int column) {
		super(color, board,row,column);		
	}

	@Override
	public void crush() {
	}

}