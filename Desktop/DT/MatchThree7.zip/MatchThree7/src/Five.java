
public class Five {
	Five(){
		
	}
	
	public boolean isMatchFiveCenter(Board board, Candy[][] candies, Candy candy){
		if (candy == null || candy.getcolour() == -10) return false;
		int i = candy.getRow();
		int j = candy.getColumn();
		
		// L
		if(i >= 2 && j < board.BOARDSIZE-2 && candies[i-1][j] != null && candies[i-2][j] != null && candies[i][j+1] != null && candies[i][j+2] != null
				&& candies[i-1][j].getcolour() != -10 && candies[i-2][j].getcolour() != -10 && candies[i][j+1].getcolour() != -10 && candies[i][j+2].getcolour() != -10){// 
			if (candy.getcolour() == candies[i-1][j].getcolour() && candy.getcolour() == candies[i-2][j].getcolour() && candy.getcolour() == candies[i][j+1].getcolour() && candy.getcolour() == candies[i][j+2].getcolour())
				return true;
		}
		if (j >= 2 && i < board.BOARDSIZE-2 && candies[i][j-1] != null && candies[i][j-2] != null && candies[i+1][j] != null && candies[i+2][j] != null
				&& candies[i][j-1].getcolour() != -10 && candies[i][j-2].getcolour() != -10 && candies[i+1][j].getcolour() != -10 && candies[i+2][j].getcolour() != -10){//
			if (candy.getcolour() == candies[i][j-1].getcolour() && candy.getcolour() == candies[i][j-2].getcolour() && candy.getcolour() == candies[i+1][j].getcolour() && candy.getcolour() == candies[i+2][j].getcolour())
				return true;
		}
		if (j < board.BOARDSIZE-2 && i < board.BOARDSIZE-2 && candies[i][j+1] != null && candies[i][j+2] != null && candies[i+1][j] != null && candies[i+2][j] != null
				&& candies[i][j+1].getcolour() != -10 && candies[i][j+2].getcolour() != -10  && candies[i+1][j].getcolour() != -10  && candies[i+2][j].getcolour() != -10 ){//
			if (candy.getcolour() == candies[i][j+1].getcolour() && candy.getcolour() == candies[i][j+2].getcolour() && candy.getcolour() == candies[i+1][j].getcolour() && candy.getcolour() == candies[i+2][j].getcolour())
				return true;
		}
		if (j >= 2 && i >= 2 && candies[i][j-1] != null && candies[i][j-2] != null && candies[i-1][j] != null && candies[i-2][j] != null
				&& candies[i][j-1].getcolour() != -10 && candies[i][j-2].getcolour() != -10 && candies[i-1][j].getcolour() != -10 && candies[i-2][j].getcolour() != -10){//
			if (candy.getcolour() == candies[i][j-1].getcolour() && candy.getcolour() == candies[i][j-2].getcolour() && candy.getcolour() == candies[i-1][j].getcolour() && candy.getcolour() == candies[i-2][j].getcolour())
				return true;
		}
		
		
		
		// (T) in four directions
		if (j >= 1 && j < board.BOARDSIZE - 1 && i < board.BOARDSIZE - 2 && candies[i][j-1] != null && candies[i][j+1] != null && candies[i+1][j] != null && candies[i+2][j] != null
				&& candies[i][j-1].getcolour() != -10 && candies[i][j+1].getcolour() != -10 && candies[i+1][j].getcolour() != -10 && candies[i+2][j].getcolour() != -10){//
			if (candy.getcolour() == candies[i][j-1].getcolour() && candy.getcolour() == candies[i][j+1].getcolour() && candy.getcolour() == candies[i+1][j].getcolour() && candy.getcolour() == candies[i+2][j].getcolour())
				return true;
		}
		if (j >= 1 && j < board.BOARDSIZE - 1 && i >= 2 && candies[i][j-1] != null && candies[i][j+1] != null && candies[i-1][j] != null && candies[i-2][j] != null
				&& candies[i][j-1].getcolour() != -10 && candies[i][j+1].getcolour() != -10 && candies[i-1][j].getcolour() != -10 && candies[i-2][j].getcolour() != -10){//
			if (candy.getcolour() == candies[i][j-1].getcolour() && candy.getcolour() == candies[i][j+1].getcolour() && candy.getcolour() == candies[i-1][j].getcolour() && candy.getcolour() == candies[i-2][j].getcolour())
				return true;
		}
		if (i >= 1 && i < board.BOARDSIZE - 1 && j < board.BOARDSIZE - 2 && candies[i-1][j] != null && candies[i+1][j] != null && candies[i][j+1] != null && candies[i][j+2] != null
				&& candies[i-1][j].getcolour() != -10 && candies[i+1][j].getcolour() != -10 && candies[i][j+1].getcolour() != -10 && candies[i][j+2].getcolour() != -10){//
			if (candy.getcolour() == candies[i-1][j].getcolour() && candy.getcolour() == candies[i+1][j].getcolour() && candy.getcolour() == candies[i][j+1].getcolour() && candy.getcolour() == candies[i][j+2].getcolour())
				return true;
		}
		if (i >= 1 && i < board.BOARDSIZE - 1 && j >= 2 && candies[i-1][j] != null && candies[i+1][j] != null && candies[i][j-1] != null && candies[i][j-2] != null
				&& candies[i-1][j].getcolour() != -10 && candies[i+1][j].getcolour() != -10 && candies[i][j-1].getcolour() != -10 && candies[i][j-2].getcolour() != -10){//
			if (candy.getcolour() == candies[i-1][j].getcolour() && candy.getcolour() == candies[i+1][j].getcolour() && candy.getcolour() == candies[i][j-1].getcolour() && candy.getcolour() == candies[i][j-2].getcolour())
				return true;
		}
		

		return false;
	}
	
	public void disappearFiveCenter(Board board, Candy [][] candies, Candy candy){
		if (candy.getcolour() == -10 || candy == null) return;
		int i = candy.getRow();
		int j = candy.getColumn();
		if(i >= 2 && j < board.BOARDSIZE-2 && candies[i-1][j] != null && candies[i-2][j] != null && candies[i][j+1] != null && candies[i][j+2] != null
				&& candies[i-1][j].getcolour() != -10 && candies[i-2][j].getcolour() != -10 && candies[i][j+1].getcolour() != -10 && candies[i][j+2].getcolour() != -10){// 
			if (candy.getcolour() == candies[i-1][j].getcolour() && candy.getcolour() == candies[i-2][j].getcolour() && candy.getcolour() == candies[i][j+1].getcolour() && candy.getcolour() == candies[i][j+2].getcolour()){
				int savedcolour = candy.getcolour();
				if (candy != null) candy.crush();
				Candy newcandy = new BombCandy(savedcolour, board, i, j); 
				board.setFiveNUM(board.getFiveNUM()+1);
				board.getCandies()[i][j] = newcandy;
				if (candies[i-1][j] != null) candies[i-1][j].crush();
				if (candies[i-2][j] != null) candies[i-2][j].crush();
				if (candies[i][j+1] != null) candies[i][j+1].crush();
				if (candies[i][j+2] != null) candies[i][j+2].crush();

			}
		}
		if (j >= 2 && i < board.BOARDSIZE-2 && candies[i][j-1] != null && candies[i][j-2] != null && candies[i+1][j] != null && candies[i+2][j] != null
				&& candies[i][j-1].getcolour() != -10 && candies[i][j-2].getcolour() != -10 && candies[i+1][j].getcolour() != -10 && candies[i+2][j].getcolour() != -10){//
			if (candy.getcolour() == candies[i][j-1].getcolour() && candy.getcolour() == candies[i][j-2].getcolour() && candy.getcolour() == candies[i+1][j].getcolour() && candy.getcolour() == candies[i+2][j].getcolour()){
				int savedcolour = candy.getcolour();
				if (candy != null) candy.crush();
				Candy newcandy = new BombCandy(savedcolour, board, i, j); 
				board.setFiveNUM(board.getFiveNUM()+1);
				board.getCandies()[i][j] = newcandy;
				if (candies[i+1][j] != null) candies[i+1][j].crush();
				if (candies[i+2][j] != null) candies[i+2][j].crush();
				if (candies[i][j-1] != null) candies[i][j-1].crush();
				if (candies[i][j-2] != null) candies[i][j-2].crush();

			}
		}
		if (j < board.BOARDSIZE-2 && i < board.BOARDSIZE-2 && candies[i][j+1] != null && candies[i][j+2] != null && candies[i+1][j] != null && candies[i+2][j] != null
				&& candies[i][j+1].getcolour() != -10 && candies[i][j+2].getcolour() != -10 && candies[i+1][j].getcolour() != -10 && candies[i+2][j].getcolour() != -10){//
			if (candy.getcolour() == candies[i][j+1].getcolour() && candy.getcolour() == candies[i][j+2].getcolour() && candy.getcolour() == candies[i+1][j].getcolour() && candy.getcolour() == candies[i+2][j].getcolour()){
				int savedcolour = candy.getcolour();
				if (candy != null) candy.crush();
				Candy newcandy = new BombCandy(savedcolour, board, i, j); 
				board.setFiveNUM(board.getFiveNUM()+1);
				board.getCandies()[i][j] = newcandy;
				if (candies[i+1][j] != null) candies[i+1][j].crush();
				if (candies[i+2][j] != null) candies[i+2][j].crush();
				if (candies[i][j+1] != null) candies[i][j+1].crush();
				if (candies[i][j+2] != null) candies[i][j+2].crush();

			}
		}
		if (j >= 2 && i >= 2 && candies[i][j-1] != null && candies[i][j-2] != null && candies[i-1][j] != null && candies[i-2][j] != null
				&& candies[i][j-1].getcolour() != -10 && candies[i][j-2].getcolour() != -10 && candies[i-1][j].getcolour() != -10 && candies[i-2][j].getcolour() != -10){//
			if (candy.getcolour() == candies[i][j-1].getcolour() && candy.getcolour() == candies[i][j-2].getcolour() && candy.getcolour() == candies[i-1][j].getcolour() && candy.getcolour() == candies[i-2][j].getcolour()){
				int savedcolour = candy.getcolour();
				if (candy != null) candy.crush();
				Candy newcandy = new BombCandy(savedcolour, board, i, j); 
				board.setFiveNUM(board.getFiveNUM()+1);
				board.getCandies()[i][j] = newcandy;
				if (candies[i-1][j] != null) candies[i-1][j].crush();
				if (candies[i-2][j] != null) candies[i-2][j].crush();
				if (candies[i][j-1] != null) candies[i][j-1].crush();
				if (candies[i][j-2] != null) candies[i][j-2].crush();

			}
		}
		

		if (j >= 1 && j < board.BOARDSIZE-1 && i< board.BOARDSIZE-2 && candies[i][j-1] != null && candies[i][j+1] != null && candies[i+1][j] != null && candies[i+2][j] != null
				&& candies[i][j-1].getcolour() != -10 && candies[i][j+1].getcolour() != -10 && candies[i+1][j].getcolour() != -10 && candies[i+2][j].getcolour() != -10){//
			if (candy.getcolour() == candies[i][j-1].getcolour() && candy.getcolour() == candies[i][j+1].getcolour() && candy.getcolour() == candies[i+1][j].getcolour() && candy.getcolour() == candies[i+2][j].getcolour()){
				int savedcolour = candy.getcolour();
				if (candy != null) candy.crush();
				Candy newcandy = new BombCandy(savedcolour, board, i, j); 
				board.setFiveNUM(board.getFiveNUM()+1);
				board.getCandies()[i][j] = newcandy;
				if (candies[i+1][j] != null) candies[i+1][j].crush();
				if (candies[i+2][j] != null) candies[i+2][j].crush();
				if (candies[i][j-1] != null) candies[i][j-1].crush();
				if (candies[i][j+1] != null) candies[i][j+1].crush();

			}
		}
		if (j >= 1 && j < board.BOARDSIZE-1 && i >= 2 && candies[i][j-1] != null && candies[i][j+1] != null && candies[i-1][j] != null && candies[i-2][j] != null
				&& candies[i][j-1].getcolour() != -10 && candies[i][j+1].getcolour() != -10 && candies[i-1][j].getcolour() != -10 && candies[i-2][j].getcolour() != -10){//
			if (candy.getcolour() == candies[i][j-1].getcolour() && candy.getcolour() == candies[i][j+1].getcolour() && candy.getcolour() == candies[i-1][j].getcolour() && candy.getcolour() == candies[i-2][j].getcolour()){
				int savedcolour = candy.getcolour();
				if (candy != null) candy.crush();
				Candy newcandy = new BombCandy(savedcolour, board, i, j); 
				board.setFiveNUM(board.getFiveNUM()+1);
				board.getCandies()[i][j] = newcandy;
				if (candies[i-1][j] != null) candies[i-1][j].crush();
				if (candies[i-2][j] != null) candies[i-2][j].crush();
				if (candies[i][j-1] != null) candies[i][j-1].crush();
				if (candies[i][j+1] != null) candies[i][j+1].crush();

			}
		}
		if (i >= 1 && i < board.BOARDSIZE-1 && j< board.BOARDSIZE-2 && candies[i-1][j] != null && candies[i+1][j] != null && candies[i][j+1] != null && candies[i][j+2] != null
				 && candies[i-1][j].getcolour() != -10 && candies[i+1][j].getcolour() != -10 && candies[i][j+1].getcolour() != -10 && candies[i][j+2].getcolour() != -10){//
			if (candy.getcolour() == candies[i-1][j].getcolour() && candy.getcolour() == candies[i+1][j].getcolour() && candy.getcolour() == candies[i][j+1].getcolour() && candy.getcolour() == candies[i][j+2].getcolour()){
				int savedcolour = candy.getcolour();
				if (candy != null) candy.crush();
				candies[i][j] = new BombCandy(savedcolour,board,i,j);
				board.setFiveNUM(board.getFiveNUM()+1);
				if (candies[i-1][j] != null) candies[i-1][j].crush();
				if (candies[i+1][j] != null) candies[i+1][j].crush();
				if (candies[i][j+1] != null) candies[i][j+1].crush();
				if (candies[i][j+2] != null) candies[i][j+2].crush();

			}
		}
		if (i >= 1 && i < board.BOARDSIZE-1 && j >= 2 && candies[i-1][j] != null && candies[i+1][j] != null && candies[i][j-1] != null && candies[i][j-2] != null
				&& candies[i-1][j].getcolour() != -10 && candies[i+1][j].getcolour() != -10 && candies[i][j-1].getcolour() != -10 && candies[i][j-2].getcolour() != -10){//
			if (candy.getcolour() == candies[i-1][j].getcolour() && candy.getcolour() == candies[i+1][j].getcolour() && candy.getcolour() == candies[i][j-1].getcolour() && candy.getcolour() == candies[i][j-2].getcolour()){
				int savedcolour = candy.getcolour();
				if (candy != null) candy.crush();
				candies[i][j] = new BombCandy(savedcolour,board,i,j);
				board.setFiveNUM(board.getFiveNUM()+1);
				if (candies[i-1][j] != null) candies[i-1][j].crush();
				if (candies[i+1][j] != null) candies[i+1][j].crush();
				if (candies[i][j-1] != null) candies[i][j-1].crush();
				if (candies[i][j-2] != null) candies[i][j-2].crush();

			}
		}
	}
	

	
	public boolean isNoMatchFive(Board board, Candy[][] candies) {
		for (int row = 0; row < board.BOARDSIZE; row = row+1){ 
			for (int column = 0; column < board.BOARDSIZE; column = column+1){
				if(isMatchFiveCenter(board, candies, candies[row][column])){
					return true;
				}
			}
		}
		return false;
	}
	
}
